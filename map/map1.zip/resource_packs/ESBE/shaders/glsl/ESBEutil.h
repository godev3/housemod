#ifndef ESBE_UTIL_INCLUDED
#define ESBE_UTIL_INCLUDED

//=*=設定項目=*=
//草木の揺れ
#define LEAVES_WAVES
//水の波
#define WATER_WAVES
#define ESBE_WATER vec2(1.0,0.5)
//光源
#define ESBE_LIGHT vec3(0.700,0.500,0.300)
//陰
#define ESBE_SHADOW vec3(0.0,0.0,0.0)
float blur = 0.005;//影の境界(数が大きいほどぼやける)
#define ESBE_FLAT_SHADING//ブロック側面の影
//日光
#define ESBE_SUN_LIGHT 0.5//昼間の明るさ向上
//夕焼け
#define DUSK 0.25//夕焼けの色の強さ
float dusk1 = 0.25;//境界位置
float dusk2 = 0.25;//境界ブラー
//トーンマップ
#define ESBE_TONEMAP
#define TM_SATURATION 1.17//色の強さ
#define TM_EXPOSURE 1.0//雨天時と晴天時の演出の差
#define TM_BRIGHTNESS 1.0//全体的な明るさ
#define TM_GAMMA 1.0//描写の「硬さ」
#define TM_CONTRAST 1.0//彩度
//オーロラ
#define RENDERAURORA
#define AURORA_RP 8.0//レイヤー数
#define AURORA_DS 2.5//レイヤー間の距離
#define AURORA_CC 0.2//レイヤー間色変化
#define AURORA_CS 6.0//色の濃さ
//雲
#define RENDERCLOUDS 8
#define CLOUDS_DC vec3(1.3,1.3,1.1)
#define CLOUDS_SC vec3(1.4,1.0,0.6)
#define CLOUDS_NC vec3(0.2,0.21,0.25)
//=*=-*-=*=

#endif
